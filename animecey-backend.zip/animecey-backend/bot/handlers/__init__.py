"""Register all bot handlers on import."""

from bot.handlers.admin import register as register_admin
from bot.handlers.upload import register as register_upload
from bot.handlers.callbacks import register as register_callbacks
from bot.handlers.quick_upload import register as register_quick_upload
from bot.handlers.fiche import register as register_fiche
from bot.handlers.vignettes import register as register_vignettes
from bot.handlers.bilan import register as register_bilan
from bot.handlers.ajouter import register as register_ajouter
from bot.handlers.supprimer import register as register_supprimer
from bot.handlers.alias import register as register_alias
from bot.handlers.delsaison import register as register_delsaison
from bot.handlers.delep import register as register_delep
from bot.handlers.signalements import register as register_signalements
from bot.handlers.thumbsr2 import register as register_thumbsr2
from bot.handlers.live import register as register_live
from bot.handlers.calendrier import register as register_calendrier
from bot.handlers.pubs import register as register_pubs
from bot.handlers.notification import register as register_notification
from bot.handlers.stats import register as register_stats


def register_all(bot):
    register_quick_upload(bot)  # en premier : /anime et les envois par légende
    register_fiche(bot)         # /fiche : choisir la fiche TMDB d'un animé
    register_vignettes(bot)     # /vignettes : vignettes des épisodes depuis TMDB
    register_bilan(bot)         # /bilan : ce qui est en ligne pour un animé
    register_ajouter(bot)       # /ajouter : ajouter un animé absent du catalogue
    register_supprimer(bot)     # /supprimer : supprimer un animé (avec confirmation)
    register_alias(bot)         # /alias : autres noms d'un animé (recherche)
    register_delsaison(bot)     # /delsaison : supprimer une seule saison
    register_delep(bot)         # /delep : supprimer un seul épisode
    register_signalements(bot)  # /signalements : problèmes signalés depuis le site
    register_thumbsr2(bot)      # /thumbsr2 : migrer les vignettes vers Cloudflare R2
    register_live(bot)          # /add : films et séries live-action (TMDB)
    register_calendrier(bot)    # /check, /calsync : calendrier des sorties
    register_pubs(bot)          # /pub, /pubs : pubs vendues à la main
    register_notification(bot)  # /notification : notification à tous les utilisateurs de l'app
    register_stats(bot)         # /stats : chiffres du site et de l'app
    register_admin(bot)
    register_upload(bot)
    register_callbacks(bot)
