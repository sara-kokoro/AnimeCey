/**
 * Pont avec l'application Android (Capacitor) : téléchargements en arrière-plan, avec notification
 * de progression et bouton « Annuler », gérés par le plugin natif MagiDownloader (dossier app/native).
 * Dans un navigateur normal, rien de tout ça n'existe : isNativeApp() renvoie false et le site
 * utilise les téléchargements internes du navigateur (IndexedDB).
 */

export interface NativeItem {
  episodeId: number;
  status: "pending" | "downloading" | "done" | "error" | "cancelled";
  /** 0 à 100 */
  progress: number;
  /** octets déjà enregistrés */
  size: number;
  /** chemin du fichier, quand le téléchargement est terminé */
  path?: string;
  error?: string;
  /** JSON : infos de l'épisode données au démarrage (titre, saison...) */
  meta?: string;
  downloadedAt?: number;
}

export interface NativePlugin {
  start(o: { episodeId: number; apiBase: string; meta: string; title: string; subtitle: string }): Promise<void>;
  cancel(o: { episodeId: number }): Promise<void>;
  remove(o: { episodeId: number }): Promise<void>;
  list(): Promise<{ items: NativeItem[] }>;
  requestPermissions(): Promise<unknown>;
  addListener(event: "downloadUpdate", cb: (item: NativeItem) => void): Promise<{ remove: () => Promise<void> }>;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function cap(): any {
  return typeof window === "undefined" ? undefined : (window as any).Capacitor;
}

export function isNativeApp(): boolean {
  try {
    const c = cap();
    // Accès direct (celui qui fonctionnait déjà), puis API officielle de Capacitor en secours
    return !!c?.isNativePlatform?.() && (!!c?.Plugins?.MagiDownloader || !!c?.isPluginAvailable?.("MagiDownloader"));
  } catch {
    return false;
  }
}

let plugin: NativePlugin | null = null;

export function nativePlugin(): NativePlugin {
  if (!plugin) {
    const c = cap();
    plugin = (c.Plugins?.MagiDownloader ?? c.registerPlugin("MagiDownloader")) as NativePlugin;
  }
  return plugin;
}

/** Adresse lisible par la page pour un fichier du téléphone. */
export function nativeFileUrl(path: string): string {
  const c = cap();
  if (typeof c?.convertFileSrc === "function") return c.convertFileSrc(path) as string;
  // Page hors connexion affichée par Capacitor (errorPath) : le pont Capacitor n'y est pas injecté (window.Capacitor
  // n'existe pas). On fabrique la même adresse que convertFileSrc sur Android : https://localhost/_capacitor_file_/chemin
  const chemin = path.replace(/^file:\/\//, "");
  return `${location.origin}/_capacitor_file_${chemin.startsWith("/") ? "" : "/"}${chemin}`;
}
